const swconf = {
  
    cacheName: 'chirpy-1762875605',resources: [
      '/assets/css/jekyll-theme-chirpy.css',
      '/',
      
        '/categories/',
      
        '/tags/',
      
        '/archives/',
      
        '/about/',
      

      
      
    ],

    interceptor: {paths: [
        
      ],urlPrefixes: [
        
      ]
    },

    purge: false
  
};

